
window.addEventListener('contextmenu', (event) => {
    alert("dsd");
  })

  var menu_open = false;

const more = document.querySelectorAll('.more-button');
var more_menu = document.querySelector('.more-menu');

//more.forEach(el => el.addEventListener('click', event => {
//    if(menu_open == false){
//        menu_open = true;
//        more_menu.style.left = "15px";
//    }else{
//        menu_open = false;
//        more_menu.style.left = "-210px";
//    }
//}));